#!/bin/sh

for dir in ./*
	   do
	       if [[ -d $dir ]]; then 
		   echo $dir
		   mkdir -p $dir/{porte1,porte2,porte3}
	       fi
	       
done
