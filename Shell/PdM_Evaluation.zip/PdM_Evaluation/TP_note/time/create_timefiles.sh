#!/bin/sh

i=1
while [[ $i -lt 100 ]] ; do
    TMPFILE=`mktemp XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX` &&  sleep 1 && touch $TMPFILE
done

    
